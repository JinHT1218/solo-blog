title: 我在 GitHub 上的开源项目
date: '2019-09-12 16:03:06'
updated: '2019-09-12 16:03:06'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [TestSDK](https://github.com/JinHT1218/TestSDK) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/TestSDK/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/TestSDK/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/TestSDK/network/members "分叉数")</span>

Test Lib



---

### 2. [SDKTest](https://github.com/JinHT1218/SDKTest) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/SDKTest/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/SDKTest/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/SDKTest/network/members "分叉数")</span>





---

### 3. [SmartChat](https://github.com/JinHT1218/SmartChat) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JinHT1218/SmartChat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/SmartChat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/SmartChat/network/members "分叉数")</span>

frist commit



---

### 4. [ViewPagerGuide](https://github.com/JinHT1218/ViewPagerGuide) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/ViewPagerGuide/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/ViewPagerGuide/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/ViewPagerGuide/network/members "分叉数")</span>

UI



---

### 5. [vrlauncher](https://github.com/JinHT1218/vrlauncher) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/vrlauncher/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/vrlauncher/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/vrlauncher/network/members "分叉数")</span>





---

### 6. [guideactivity](https://github.com/JinHT1218/guideactivity) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/guideactivity/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/guideactivity/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/guideactivity/network/members "分叉数")</span>





---

### 7. [PowerManagerActivity1](https://github.com/JinHT1218/PowerManagerActivity1) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/PowerManagerActivity1/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/PowerManagerActivity1/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/PowerManagerActivity1/network/members "分叉数")</span>





---

### 8. [CocoBill-master](https://github.com/JinHT1218/CocoBill-master) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JinHT1218/CocoBill-master/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JinHT1218/CocoBill-master/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JinHT1218/CocoBill-master/network/members "分叉数")</span>



